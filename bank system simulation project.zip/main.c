#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct operation_type {
    char optname[100];
    float commission;
    int optnum;
    struct operation_type* nextopt;
} operation_type;

typedef struct transaction{
    int optype;
    int tno;
    float amount;
    struct transaction* nexttr;
} transacation;

typedef struct customer {
    char fname[100];
    char lname[100];
    int cno;
    float paid_commission;
    transacation** trans;
    struct customer* nextc;
} customer;

typedef struct branch {
    char bname[100];
    int bno;
    customer** custs;
    struct branch* nextb;
} branch;

typedef struct bank {
    branch** branches;
    operation_type** optypes;
} bank;

void appendOptType(operation_type **head_ref, char optname[], float commission, int count) {
    operation_type * new_node = (operation_type *) malloc(sizeof (operation_type));
    operation_type * last = *head_ref;

    memcpy(new_node->optname,optname, 100);
    new_node->commission = commission;
    new_node->optnum = count;
    new_node->nextopt = NULL;

    if (*head_ref == NULL) {
        *head_ref = new_node;
        return;
    }

    while (last->nextopt != NULL)
        last = last->nextopt;

    last->nextopt = new_node;
}

void appendBranch(branch **head_ref, char bname[], int bno) {
    branch * new_node =  (branch *)malloc(sizeof(branch));
    branch * last = *head_ref;

    memcpy(new_node->bname,bname, 100);
    new_node->bno = bno;
    new_node->custs = (customer **)malloc(sizeof (customer));
    new_node->nextb = NULL;

    if (*head_ref == NULL) {
        *head_ref = new_node;
        return;
    }

    while (last->nextb != NULL)
        last = last->nextb;

    last->nextb = new_node;
}

void appendCustomer(bank** bank, char fname[], char lname[], int bno) {
    branch ** head = (*bank)->branches;
    while(bno != (*head)->bno) {
        head = &((*head)->nextb);
    }
    int cno = 1;


    customer ** head_ref = (*head)->custs;

    customer * new_node =  (customer *)malloc(sizeof(customer));
    customer * last = *head_ref;

    memcpy(new_node->fname,fname, 100);
    memcpy(new_node->lname,lname, 100);
    new_node->trans = (transacation **)malloc(sizeof (transacation));
    new_node->nextc = NULL;

    if (*head_ref == NULL) {
        new_node->cno = cno;
        *head_ref = new_node;
        return;
    }

    cno++;
    while (last->nextc != NULL){
        last = last->nextc;
        cno++;
    }

    new_node->cno = cno;
    last->nextc = new_node;
}

void appendTransactions(bank** bank, int bno, int cno, int optype, float amount) {
    branch ** headB = (*bank)->branches;
    while(bno != (*headB)->bno) {
        headB = &((*headB)->nextb);
    }

    customer ** headC = (*headB) -> custs;
    while (cno != (*headC)->cno) {
        headC = &((*headC)->nextc);
    }

    int tno = 1;

    transacation ** head_ref = (*headC)->trans;

    transacation * new_node =  (transacation *)malloc(sizeof(transacation));
    transacation * last = *head_ref;

    new_node->amount = amount;
    new_node->optype = optype;
    new_node->nexttr = NULL;

    if (*head_ref == NULL) {
        new_node->tno = tno;
        *head_ref = new_node;
        return;
    }

    tno++;
    while (last->nexttr != NULL){
        last = last->nexttr;
        tno++;
    }

    new_node->tno = tno;
    last->nexttr = new_node;
}

void printOperationTypes(bank* bank) {
    operation_type * temp = *(bank->optypes);

    printf("\noptypes linked list :\n");
    while (temp != NULL) {
        printf("--%d %s %.1f\n", temp->optnum, temp->optname, temp->commission);
        temp = temp->nextopt;
    }
}

void printBranches(bank* bank) {
    branch * temp = *(bank->branches);

    printf("\nbranches linked list :\n");
    while (temp != NULL) {
        printf("BRANCH : %d %s\n", temp->bno, temp->bname);
        temp = temp->nextb;
    }
}

void printCustomers(bank* bank) {
    branch * temp = *(bank->branches);

    printf("\n******************************\n");
    while (temp != NULL) {
        printf("BRANCH : %d %s\n", temp->bno, temp->bname);
        customer * tempCustomer = *(temp->custs);
        while (tempCustomer != NULL) {
            printf("\t--%d %s %s\n", tempCustomer->cno, tempCustomer->fname, tempCustomer->lname);
            tempCustomer = tempCustomer->nextc;
        }
        temp = temp->nextb;
    }
}

void printTransactions(bank* bank) {
    branch * temp = *(bank->branches);

    printf("\n******************************\n");
    while (temp != NULL) {
        printf("BRANCH : %d %s\n", temp->bno, temp->bname);
        customer * tempCustomer = *(temp->custs);
        while (tempCustomer != NULL) {
            printf("\t--%d %s %s\n", tempCustomer->cno, tempCustomer->fname, tempCustomer->lname);
            transacation * tempTransaction = *(tempCustomer->trans);
            while (tempTransaction != NULL) {
                printf("\t\t\t++tno %d operation type (optype) %d amount %.2f\n", tempTransaction->tno, tempTransaction->optype, tempTransaction->amount);
                tempTransaction = tempTransaction->nexttr;
            }
            tempCustomer = tempCustomer->nextc;
        }
        temp = temp->nextb;
    }
}

void printPaidCommission(bank* bank) {
    branch * tempB = *(bank->branches);


    printf("\n******************************\n");
    while (tempB != NULL) {
        printf("BRANCH : %s\n", tempB->bname);
        customer * tempCustomer = *(tempB->custs);
        while (tempCustomer != NULL) {
            printf("--> cust id %d : %s %s\n", tempCustomer->cno, tempCustomer->fname, tempCustomer->lname);
            transacation * tempTransaction = *(tempCustomer->trans);
            if(tempTransaction == NULL) {
                printf("\t--(customer has no transaction)\n");
            }
            while (tempTransaction != NULL) {
                operation_type * tempO = *(bank->optypes);
                while(tempO->optnum != tempTransaction->optype) {
                    tempO = tempO->nextopt;
                }
                printf("\t++tno %d optype %d commission rate %.2f amount %.2f paid commission %.2f", tempTransaction->tno, tempTransaction->optype, tempO->commission, tempTransaction->amount, (tempTransaction->amount * tempO->commission / 100));
                tempCustomer->paid_commission += tempTransaction->amount * tempO->commission / 100;
                printf(" total commission %.2f\n", tempCustomer->paid_commission);
                tempTransaction = tempTransaction->nexttr;
            }
            printf("\t** paid commission %.2f\n", tempCustomer->paid_commission);
            tempCustomer = tempCustomer->nextc;
        }
        tempB = tempB->nextb;
    }
}

int countLinesFunc(char folderName[]) {
    int countLines = 1;
    char chr;

    FILE* ptr;
    ptr = fopen(folderName, "r");

    chr = getc(ptr);
    while (chr != EOF){
        if (chr == '\n'){
            countLines = countLines + 1;
        }
        chr = getc(ptr);
    }

    return countLines;
}

void readOperationTypes(bank** bank) {
    int count = 1;
    char folderName[100];
    printf("Please enter the name of the input file : \n");
    scanf("%s", folderName);

    FILE* ptr;
    ptr = fopen(folderName, "r");

    int countLines = countLinesFunc(folderName);

    while(count - 1 != countLines) {
        char optname[100];
        float commission = 0;
        fscanf(ptr, "%s %f\n", optname, &commission);
        appendOptType((operation_type **) (*bank)->optypes, optname, commission, count++);
    }
}

void readBranches(bank** bank) {
    int count = 1;
    char folderName[100];
    printf("Please enter the name of the input file : \n");
    scanf("%s", folderName);

    FILE* ptr;
    ptr = fopen(folderName, "r");

    int countLines = countLinesFunc(folderName);

    while(count - 1 != countLines) {
        char bname[100];
        fscanf(ptr, "%s\n", bname);
        appendBranch((branch **) (*bank)->branches, bname, count++);
    }
}

void readCustomers(bank** bank) {
    int count = 1;
    char folderName[100];
    printf("Please enter the name of the input file : \n");
    scanf("%s", folderName);

    FILE* ptr;
    ptr = fopen(folderName, "r");

    int countLines = countLinesFunc(folderName);

    while(count - 1 != countLines) {
        int bno;
        char fname[100];
        char lname[100];
        fscanf(ptr, "%d %s %s\n", &bno, fname, lname);
        appendCustomer(bank, fname, lname, bno);
        count++;
    }
}

void readTransactions(bank** bank) {
    int count = 1;
    char folderName[100];
    printf("Please enter the name of the input file : \n");
    scanf("%s", folderName);

    FILE* ptr;
    ptr = fopen(folderName, "r");

    int countLines = countLinesFunc(folderName);

    while(count - 1 != countLines) {
        int bno;
        int cno;
        int optype;
        float amount;
        fscanf(ptr, "%d %d %d %f\n", &bno, &cno, &optype, &amount);
        appendTransactions(bank, bno, cno, optype, amount);
        count++;
    }
}


int main() {
    bank** bank1 = (bank**)malloc(sizeof (&bank1));
    *(bank1) = (bank *)malloc(sizeof (bank));
    (*bank1)->branches = (branch **)malloc(sizeof (branch*));
    (*bank1)->optypes = (operation_type **)malloc(sizeof (operation_type*));

    while (1) {
        printf("\n1) Read operation types from the file\n"
               "2) Read branches from the file\n"
               "3) Read customers from the file\n"
               "4) Read customer transactions from the file\n"
               "5) Calculate paid commission amount of each customers in each branches\n");

        int selection;
        scanf("%d", &selection);

        switch (selection) {
            case 1:
                readOperationTypes(bank1);
                printOperationTypes(*bank1);
                break;
            case 2:
                readBranches(bank1);
                printBranches(*bank1);
                break;
            case 3:
                readCustomers(bank1);
                printCustomers(*bank1);
                break;
            case 4:
                readTransactions(bank1);
                printTransactions(*bank1);
                break;
            case 5:
                printPaidCommission(*bank1);
                break;
            default:
                exit(6);
        }
    }
}



